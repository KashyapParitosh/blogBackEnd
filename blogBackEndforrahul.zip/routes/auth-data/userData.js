
const userList = [
    { id : 1, userName : "Paritosh" , email: "paritoshkashyap25@gmail.com", password : "paritosh@123"},
    { id : 2, username : 'test', email : "test@1234", password : "test@1234" },

]

module.exports = userList;