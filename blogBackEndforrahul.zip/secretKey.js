const jwtSecretKey = "thisISABlogProjectSecretKey"

module.exports = jwtSecretKey